package animals;


public class AnimalChicken extends Animal {
	
	/**
	 * Constructor for the 'chicken' type of animal.
	 */
	public AnimalChicken() {
		super("Chicken", 150.00, 50.00, 75.00, 75.00);
	}
}
