package animals;


public class AnimalCow extends Animal {
	
	/**
	 * Constructor for the 'cow' type of animal.
	 */
	public AnimalCow() {
		super("Cow", 400.00, 150.00, 65.00, 70.00);
	}
}
