package items;

public class ItemSteroids extends ItemForAnimal {
	
	/**
	 * Constructs the item with correct values
	 */
	public ItemSteroids() {
		super("Steroids", 14.99, 35.0);
	}

}
