package items;

public class ItemGrowLight extends ItemForCrop {
	
	/**
	 * Constructs the item with correct values
	 */
	public ItemGrowLight() {
		super("Hydroponic Grow Lights", 24.99, 4.0);
	}

}
