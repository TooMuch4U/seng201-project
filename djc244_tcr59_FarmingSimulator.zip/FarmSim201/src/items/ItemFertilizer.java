package items;

public class ItemFertilizer extends ItemForCrop {
	
	/** 
	 * Constructor for ItemFertilizer
	 */
	public ItemFertilizer() {
		super("Fertilizer", 9.99, 2.0);
	}

}
