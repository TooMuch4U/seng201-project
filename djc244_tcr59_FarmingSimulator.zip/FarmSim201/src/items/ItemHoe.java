package items;

public class ItemHoe extends ItemForCrop {
	
	/**
	 * Constructor for ItemHoe
	 */
	public ItemHoe() {
		super("Hoe", 19.99, 3.00);
	}

}
