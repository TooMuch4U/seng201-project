package items;

public class ItemApple extends ItemForAnimal {

	/**
	 * Constructor for ItemApple
	 */
	public ItemApple() {
		super("Apple", 1.99, 3.00);
	}

}
