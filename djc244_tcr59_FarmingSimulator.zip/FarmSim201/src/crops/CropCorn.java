package crops;


public class CropCorn extends Crop {
	
	/**
	 * Constructor for the cabbage type of crop.
	 */
	public CropCorn() {
		super("Corn", 10.00, 35.00, 2);
	}
}
