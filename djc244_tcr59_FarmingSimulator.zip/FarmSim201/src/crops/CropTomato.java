package crops;


public class CropTomato extends Crop {
	
	/**
	 * Constructor for the cabbage type of crop.
	 */
	public CropTomato() {
		super("Tomato", 5.00, 12.50, 1);
	}
}
