package crops;


public class CropCauliflower extends Crop {
	
	/**
	 * Constructor for the cauliflower type of crop.
	 */
	public CropCauliflower() {
		super("Cauliflower", 20.00, 50.00, 4);
	}
}
