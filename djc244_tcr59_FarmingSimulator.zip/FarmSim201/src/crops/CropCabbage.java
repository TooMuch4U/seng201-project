package crops;


public class CropCabbage extends Crop {
	
	/**
	 * Constructor for the cabbage type of crop.
	 */
	public CropCabbage() {
		super("Cabbage", 10.00, 30.00, 3);
	}
}
