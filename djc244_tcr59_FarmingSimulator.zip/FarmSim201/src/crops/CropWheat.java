package crops;


public class CropWheat extends Crop {
	
	/**
	 * Constructor for the cabbage type of crop.
	 */
	public CropWheat() {
		super("Wheat", 2.50, 10.00, 1);
	}
}
