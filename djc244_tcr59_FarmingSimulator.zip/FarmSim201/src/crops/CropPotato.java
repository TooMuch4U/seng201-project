package crops;


public class CropPotato extends Crop {
	
	/**
	 * Constructor for the cabbage type of crop.
	 */
	public CropPotato() {
		super("Potato", 5.00, 15.00, 2);
	}
}
